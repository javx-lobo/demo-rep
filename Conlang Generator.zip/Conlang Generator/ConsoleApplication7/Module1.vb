﻿Module Module1

    Sub Main()
        Dim sillabe(), S(6), V(999), O(9999), D(4), A(99), P, N As String
        Dim ploor, interrog, negat, adj As Integer
        '  Console.WriteLine("Give number of syllabes: ")
        'Dim nusy = CInt(Console.ReadLine())
        'ReDim sillabe(nusy)
        'For cont = 0 To nusy - 1
        'Console.WriteLine("Syllabe " & cont + 1 & ": ")
        'sillabe(cont) = Console.ReadLine()
        ' Next
        sillabe = {"b", "d", "f", "g", "k", "l", "m", "n", "p", "r", "s", "t", "v", "w", "z", "ng", "sh", "j", "'", "dz", "ts"}
        Dim rnd As New Random()
        Dim ctrl As Integer

        P = sillabe(rnd.Next(1, sillabe.GetLength(0)))
        N = sillabe(rnd.Next(1, sillabe.GetLength(0)))

        For contador = 0 To 99
            For contador2 = 0 To rnd.Next(1, 4)
                ctrl = rnd.Next(1, sillabe.GetLength(0))
                A(contador) = A(contador) + sillabe(ctrl)
            Next
        Next
        For contador = 0 To 4
            For contador2 = 0 To rnd.Next(1, 3)
                ctrl = rnd.Next(1, sillabe.GetLength(0))
                D(contador) = D(contador) + sillabe(ctrl)
            Next
        Next
        For contador = 0 To 6
            For contador2 = 0 To rnd.Next(1, 6)
                ctrl = rnd.Next(1, sillabe.GetLength(0))
                S(contador) = S(contador) + sillabe(ctrl)
            Next
        Next
        For contador = 0 To 999
            For contador2 = 0 To rnd.Next(1, 6)
                ctrl = rnd.Next(1, sillabe.GetLength(0))
                V(contador) = V(contador) + sillabe(ctrl)
            Next
        Next
        For contador = 0 To 9999
            For contador2 = 0 To rnd.Next(1, 6)
                ctrl = rnd.Next(1, sillabe.GetLength(0))
                O(contador) = O(contador) + sillabe(ctrl)
            Next
        Next

        Dim path2 As String = "e:\MyResult.txt"
        ' Create or overwrite the file.
        Dim fs2 As IO.FileStream = IO.File.Create(path2)
        ' Add text to the file.
        Dim info2 As Byte() = New Text.UTF8Encoding(True).GetBytes("Subjects" & Chr(13) & Chr(10))
        fs2.Write(info2, 0, info2.Length)

        For contador = 0 To 10
            ploor = rnd.Next(0, 10)
            interrog = rnd.Next(0, 10)
            negat = rnd.Next(0, 10)
            adj = rnd.Next(0, 10)
            If adj <= 5 Then 'SIN ADJETIVOS
                If ploor > 5 Then 'EN SINGULAR
                    If interrog > 5 And negat > 5 Then
                        Console.WriteLine(S(rnd.Next(0, 6)) & "-" & D(rnd.Next(0, 4)) & " " & O(rnd.Next(0, 9999)) & " " & V(rnd.Next(0, 999)) & ".") 'sov
                        info2 = New Text.UTF8Encoding(True).GetBytes(S(rnd.Next(0, 6)) & "-" & D(rnd.Next(0, 4)) & " " & O(rnd.Next(0, 9999)) & " " & V(rnd.Next(0, 999)) & "." & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                    If interrog <= 5 And negat > 5 Then
                        Console.WriteLine(V(rnd.Next(0, 999)) & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & D(rnd.Next(0, 4)) & "?") 'vsod
                        info2 = New Text.UTF8Encoding(True).GetBytes(V(rnd.Next(0, 999)) & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & D(rnd.Next(0, 4)) & "?" & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                    If interrog > 5 And negat <= 5 Then
                        Console.WriteLine(V(rnd.Next(0, 999)) & " " & N & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & D(rnd.Next(0, 4)) & ".") 'vnsod
                        info2 = New Text.UTF8Encoding(True).GetBytes(V(rnd.Next(0, 999)) & " " & N & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & D(rnd.Next(0, 4)) & "." & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                ElseIf ploor <= 5 Then 'EN PLURAL
                    If interrog > 5 And negat > 5 Then
                        Console.WriteLine(S(rnd.Next(0, 6)) & "-" & D(rnd.Next(0, 4)) & P & " " & O(rnd.Next(0, 9999)) & P & " " & V(rnd.Next(0, 999)) & ".") 'sdpopv
                        info2 = New Text.UTF8Encoding(True).GetBytes(S(rnd.Next(0, 6)) & "-" & D(rnd.Next(0, 4)) & P & " " & O(rnd.Next(0, 9999)) & P & " " & V(rnd.Next(0, 999)) & "." & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                    If interrog <= 5 And negat > 5 Then
                        Console.WriteLine(V(rnd.Next(0, 999)) & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & P & " " & D(rnd.Next(0, 4)) & P & "?") 'vsopdp
                        info2 = New Text.UTF8Encoding(True).GetBytes(V(rnd.Next(0, 999)) & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & P & " " & D(rnd.Next(0, 4)) & P & "?" & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                    If interrog > 5 And negat <= 5 Then
                        Console.WriteLine(V(rnd.Next(0, 999)) & " " & N & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & P & " " & D(rnd.Next(0, 4)) & P & ".") 'vnsopdp
                        info2 = New Text.UTF8Encoding(True).GetBytes(V(rnd.Next(0, 999)) & " " & N & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & P & " " & D(rnd.Next(0, 4)) & P & "." & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                End If
            End If
            If adj <= 5 Then 'CON ADJETIVOS
                If ploor > 5 Then 'EN SINGULAR
                    If interrog > 5 And negat > 5 Then 'AFIRMATIVA
                        Console.WriteLine(S(rnd.Next(0, 6)) & "-" & D(rnd.Next(0, 4)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & " " & V(rnd.Next(0, 999)) & ".") 'sdoav
                        info2 = New Text.UTF8Encoding(True).GetBytes(S(rnd.Next(0, 6)) & "-" & D(rnd.Next(0, 4)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & " " & V(rnd.Next(0, 999)) & "." & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                    If interrog <= 5 And negat > 5 Then 'INTERROGATIVA
                        Console.WriteLine(V(rnd.Next(0, 999)) & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & " " & D(rnd.Next(0, 4)) & "?") 'vsoad
                        info2 = New Text.UTF8Encoding(True).GetBytes(V(rnd.Next(0, 999)) & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & " " & D(rnd.Next(0, 4)) & "?" & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                    If interrog > 5 And negat <= 5 Then 'NEGATIVA
                        Console.WriteLine(V(rnd.Next(0, 999)) & " " & N & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & " " & D(rnd.Next(0, 4)) & ".") 'vnsoad
                        info2 = New Text.UTF8Encoding(True).GetBytes(V(rnd.Next(0, 999)) & " " & N & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & " " & D(rnd.Next(0, 4)) & "." & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                ElseIf ploor <= 5 Then 'EN PLURAL
                    If interrog > 5 And negat > 5 Then
                        Console.WriteLine(S(rnd.Next(0, 6)) & "-" & D(rnd.Next(0, 4)) & P & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & P & " " & V(rnd.Next(0, 999)) & ".") 'sdpoapv
                        info2 = New Text.UTF8Encoding(True).GetBytes(S(rnd.Next(0, 6)) & "-" & D(rnd.Next(0, 4)) & P & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & P & " " & V(rnd.Next(0, 999)) & "." & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                    If interrog <= 5 And negat > 5 Then
                        Console.WriteLine(V(rnd.Next(0, 999)) & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & P & " " & D(rnd.Next(0, 4)) & P & "?") 'vsopdp
                        info2 = New Text.UTF8Encoding(True).GetBytes(V(rnd.Next(0, 999)) & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & P & " " & D(rnd.Next(0, 4)) & P & "?" & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                    If interrog > 5 And negat <= 5 Then
                        Console.WriteLine(V(rnd.Next(0, 999)) & " " & N & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & P & " " & D(rnd.Next(0, 4)) & P & ".") 'vnsopdp
                        info2 = New Text.UTF8Encoding(True).GetBytes(V(rnd.Next(0, 999)) & " " & N & " " & S(rnd.Next(0, 6)) & " " & O(rnd.Next(0, 9999)) & " " & A(rnd.Next(0, 99)) & P & " " & D(rnd.Next(0, 4)) & P & "." & Chr(13) & Chr(10))
                        fs2.Write(info2, 0, info2.Length)
                    End If
                End If
            End If

        Next
        Console.ReadLine()
        Dim path As String = "e:\MyTest.txt"

        ' Create or overwrite the file.
        Dim fs As IO.FileStream = IO.File.Create(path)

        ' Add text to the file.
        Dim info As Byte() = New Text.UTF8Encoding(True).GetBytes("Subjects" & Chr(13) & Chr(10))
        fs.Write(info, 0, info.Length)

        For contador = 0 To 6
            info = New Text.UTF8Encoding(True).GetBytes(contador & ". " & S(contador) & Chr(13) & Chr(10))
            fs.Write(info, 0, info.Length)
        Next
        info = New Text.UTF8Encoding(True).GetBytes("Objects" & Chr(13) & Chr(10))
        fs.Write(info, 0, info.Length)
        For contador = 0 To 9999
            info = New Text.UTF8Encoding(True).GetBytes(contador & ". " & O(contador) & Chr(13) & Chr(10))
            fs.Write(info, 0, info.Length)
        Next
        info = New Text.UTF8Encoding(True).GetBytes("Verbs" & Chr(13) & Chr(10))
        fs.Write(info, 0, info.Length)
        For contador = 0 To 999
            info = New Text.UTF8Encoding(True).GetBytes(contador & ". " & V(contador) & Chr(13) & Chr(10))
            fs.Write(info, 0, info.Length)
        Next
        info = New Text.UTF8Encoding(True).GetBytes("Determinants" & Chr(13) & Chr(10))
        fs.Write(info, 0, info.Length)
        For contador = 0 To 4
            info = New Text.UTF8Encoding(True).GetBytes(contador & ". " & D(contador) & Chr(13) & Chr(10))
            fs.Write(info, 0, info.Length)
        Next
        info = New Text.UTF8Encoding(True).GetBytes("Adjectives" & Chr(13) & Chr(10))
        fs.Write(info, 0, info.Length)
        For contador = 0 To 99
            info = New Text.UTF8Encoding(True).GetBytes(contador & ". " & A(contador) & Chr(13) & Chr(10))
            fs.Write(info, 0, info.Length)
        Next
        info = New Text.UTF8Encoding(True).GetBytes("Negative part.: " & N & "| Plural part.: " & P & Chr(13) & Chr(10))
        fs.Write(info, 0, info.Length)
        fs.Close()
    End Sub

End Module
